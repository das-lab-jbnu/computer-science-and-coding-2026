from flask import Flask
from flask import redirect
from flask import render_template
from flask import request
from flask import url_for

from services.calculator import calculate_final_score
from services.calculator import calculate_student_average
from services.evaluator_assignment_service import ensure_assignments_for_targets
from services.evaluator_assignment_service import get_or_create_evaluators
from services.evaluator_assignment_service import is_assigned_evaluator
from services.evaluator_assignment_service import regenerate_evaluators
from services.random_picker import load_classrooms
from services.score_service import has_already_submitted
from services.score_service import load_criteria
from services.score_service import load_scores
from services.score_service import save_score
from services.settings_service import close_evaluation
from services.settings_service import close_target
from services.settings_service import is_evaluation_closed
from services.settings_service import is_target_closed
from services.settings_service import reopen_evaluation
from services.storage_service import save_all_final_scores
from services.storage_service import save_final_score

app = Flask(__name__)

classrooms = load_classrooms()
criteria = load_criteria()
EVALUATION_URL = "https://hardened-device-footrest.ngrok-free.dev/evaluate"

def get_first_target():

    first_class = next(iter(classrooms))

    return {
        "class_number": first_class,
        "name": classrooms[first_class][0]
    }

def get_all_targets():

    targets = []

    for class_number, names in classrooms.items():
        for name in names:
            targets.append({
                "class_number": class_number,
                "name": name
            })

    return targets

def is_valid_target(target):

    return (
        target["class_number"] in classrooms
        and target["name"] in classrooms[target["class_number"]]
    )

def get_selected_target():

    class_number = request.values.get("target_class")
    name = request.values.get("target_name")

    if (
        class_number
        and name
        and is_valid_target({
            "class_number": class_number,
            "name": name
        })
    ):
        return {
            "class_number": class_number,
            "name": name
        }

    return get_first_target()

def get_target_scores(scores, target):

    return [
        item for item in scores
        if (
            item["target"]["class_number"] == target["class_number"]
            and item["target"]["name"] == target["name"]
        )
    ]

def build_target_options():

    return [
        {
            "class_number": target["class_number"],
            "name": target["name"],
            "closed": is_target_closed(target)
        }
        for target in get_all_targets()
    ]

def build_target_dashboard(target):

    scores = load_scores()
    assignments = ensure_assignments_for_targets(get_all_targets())
    key = f'{target["class_number"]}:{target["name"]}'
    target_scores = get_target_scores(scores, target)
    submitted_students = {
        (
            item["evaluator"]["class_number"],
            item["evaluator"]["name"]
        )
        for item in target_scores
    }
    evaluators = []

    for evaluator in assignments.get(key, []):
        evaluators.append({
            "class_number": evaluator["class_number"],
            "name": evaluator["name"],
            "submitted": (
                evaluator["class_number"],
                evaluator["name"]
            ) in submitted_students
        })

    return {
        "target": target,
        "evaluators": evaluators,
        "submitted_count": len(target_scores),
        "average": calculate_student_average(target_scores),
        "closed": is_target_closed(target)
    }

def calculate_and_save_target_final(target, professor_score):

    scores = load_scores()
    target_scores = get_target_scores(scores, target)
    student_average = calculate_student_average(target_scores)
    final_score = calculate_final_score(student_average, professor_score)

    save_final_score(
        target,
        student_average,
        professor_score,
        final_score,
        len(target_scores)
    )
    close_target(target)

    return {
        "submitted_count": len(target_scores),
        "student_average": student_average,
        "professor_score": professor_score,
        "final_score": final_score
    }

def export_final_scores():

    scores = load_scores()
    rows = []

    for target in get_all_targets():
        target_scores = get_target_scores(scores, target)
        student_average = calculate_student_average(target_scores)

        rows.append({
            "target_class": target["class_number"],
            "target_name": target["name"],
            "submitted_count": len(target_scores),
            "student_average": student_average,
            "professor_score": "",
            "final_score": student_average
        })

    save_all_final_scores(rows)

@app.route("/")
def home():

    selected_target = get_selected_target()

    return render_template(
        "professor.html",
        selected_dashboard=build_target_dashboard(selected_target),
        target_options=build_target_options(),
        selected_target=selected_target,
        classrooms=classrooms,
        criteria=criteria,
        scores=load_scores(),
        evaluation_closed=is_evaluation_closed(),
        final_result=None
    )

@app.route("/evaluate", methods=["GET", "POST"])
def evaluate():

    selected_target = get_selected_target()
    assigned_evaluators = get_or_create_evaluators(selected_target)

    if request.method == "POST":
        evaluator = {
            "class_number": request.form["evaluator_class"],
            "name": request.form["evaluator_name"]
        }
        target = {
            "class_number": request.form["target_class"],
            "name": request.form["target_name"]
        }

        if not is_valid_target(target):
            return "존재하지 않는 발표자입니다."

        if is_target_closed(target):
            return "이 발표자는 평가가 마감되었습니다."

        criteria_scores = {}

        for item in criteria:
            criteria_scores[item["id"]] = int(
                request.form[item["id"]]
            )

        if not is_assigned_evaluator(evaluator, target):
            return "선정된 평가자만 이 발표자를 평가할 수 있습니다."

        if has_already_submitted(evaluator, target):
            return "이미 이 발표자에 대한 평가를 제출했습니다."

        save_score(evaluator, target, criteria_scores)

        return "평가가 제출되었습니다."

    return render_template(
        "student.html",
        students=assigned_evaluators,
        classrooms=classrooms,
        criteria=criteria,
        selected_target=selected_target,
        target_closed=is_target_closed(selected_target)
    )

@app.route("/selection")
def selection_page():

    selected_target = get_selected_target()
    assigned_evaluators = get_or_create_evaluators(selected_target)

    return render_template(
        "selection.html",
        students=assigned_evaluators,
        classrooms=classrooms,
        selected_target=selected_target,
        evaluation_url=EVALUATION_URL,
        evaluation_closed=is_target_closed(selected_target)
    )

@app.route("/selection/refresh", methods=["POST"])
def refresh_selection():

    target = {
        "class_number": request.form["target_class"],
        "name": request.form["target_name"]
    }

    if is_valid_target(target) and not is_target_closed(target):
        regenerate_evaluators(target)

    return redirect(
        url_for(
            "selection_page",
            target_class=target["class_number"],
            target_name=target["name"]
        )
    )

@app.route("/close-target", methods=["POST"])
def close_target_page():

    target = {
        "class_number": request.form["target_class"],
        "name": request.form["target_name"]
    }

    if not is_valid_target(target):
        return redirect(url_for("home"))

    professor_criteria_scores = {}

    for item in criteria:
        professor_criteria_scores[item["id"]] = int(
            request.form[item["id"]]
        )

    result = calculate_and_save_target_final(
        target,
        sum(professor_criteria_scores.values())
    )

    return render_template(
        "professor.html",
        selected_dashboard=build_target_dashboard(target),
        target_options=build_target_options(),
        selected_target=target,
        classrooms=classrooms,
        criteria=criteria,
        scores=load_scores(),
        evaluation_closed=is_evaluation_closed(),
        final_result=result
    )

@app.route("/close", methods=["POST"])
def close_page():

    close_evaluation()
    export_final_scores()

    return redirect(url_for("home"))

@app.route("/reopen", methods=["POST"])
def reopen_page():

    reopen_evaluation()

    return redirect(url_for("home"))

@app.route("/final", methods=["GET", "POST"])
def final_page():

    scores = load_scores()
    student_average = 0
    final_score = None
    selected_target = None

    if request.method == "POST":
        selected_target = {
            "class_number": request.form["target_class"],
            "name": request.form["target_name"]
        }
        target_scores = get_target_scores(scores, selected_target)
        student_average = calculate_student_average(target_scores)
        professor_criteria_scores = {}

        for item in criteria:
            professor_criteria_scores[item["id"]] = int(
                request.form[item["id"]]
            )

        professor_score = sum(
            professor_criteria_scores.values()
        )
        final_score = calculate_final_score(
            student_average,
            professor_score
        )

        save_final_score(
            selected_target,
            student_average,
            professor_score,
            final_score,
            len(target_scores)
        )
        close_target(selected_target)

        return render_template(
            "final.html",
            classrooms=classrooms,
            criteria=criteria,
            selected_target=selected_target,
            student_average=student_average,
            professor_score=professor_score,
            professor_criteria_scores=professor_criteria_scores,
            final_score=final_score
        )

    return render_template(
        "final.html",
        classrooms=classrooms,
        criteria=criteria,
        selected_target=selected_target,
        student_average=student_average,
        final_score=final_score
    )

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )
