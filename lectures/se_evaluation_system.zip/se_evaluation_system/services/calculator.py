def calculate_student_average(scores):

    if not scores:
        return 0

    score_values = []

    for item in scores:
        score_values.append(item["total_score"])

    if len(score_values) < 10:
        return round(sum(score_values) / len(score_values), 2)

    score_values.sort()

    trimmed_scores = score_values[1:-1]

    average = sum(trimmed_scores) / len(trimmed_scores)

    return round(average, 2)

def calculate_trimmed_mean(scores):

    return calculate_student_average(scores)

def calculate_final_score(student_score, professor_score):

    final_score = (
        student_score * 0.5
        + professor_score * 0.5
    )

    return round(final_score, 2)
