import json
import os

from services.random_picker import pick_evaluators_for_target

ASSIGNMENT_FILE = "data/evaluator_assignments.json"

def _target_key(target):

    return f'{target["class_number"]}:{target["name"]}'

def load_assignments():

    if not os.path.exists(ASSIGNMENT_FILE):
        return {}

    with open(ASSIGNMENT_FILE, "r", encoding="utf-8") as file:
        return json.load(file)

def save_assignments(assignments):

    with open(ASSIGNMENT_FILE, "w", encoding="utf-8") as file:
        json.dump(assignments, file, indent=4, ensure_ascii=False)

def get_or_create_evaluators(target):

    assignments = load_assignments()
    key = _target_key(target)

    if key not in assignments:
        assignments[key] = pick_evaluators_for_target(target)
        save_assignments(assignments)

    return assignments[key]

def regenerate_evaluators(target):

    assignments = load_assignments()
    key = _target_key(target)
    assignments[key] = pick_evaluators_for_target(target)
    save_assignments(assignments)

    return assignments[key]

def ensure_assignments_for_targets(targets):

    assignments = load_assignments()
    changed = False

    for target in targets:
        key = _target_key(target)

        if key not in assignments:
            assignments[key] = pick_evaluators_for_target(target)
            changed = True

    if changed:
        save_assignments(assignments)

    return assignments

def is_assigned_evaluator(evaluator, target):

    evaluators = get_or_create_evaluators(target)

    return evaluator in evaluators
