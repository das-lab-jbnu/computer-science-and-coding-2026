import json
import random

STUDENT_FILE = "data/students.json"
DEFAULT_JUDGE_COUNT = 10

def load_classrooms():

    with open(STUDENT_FILE, "r", encoding="utf-8") as file:
        classrooms = json.load(file)

    return classrooms

def get_all_students():

    classrooms = load_classrooms()
    students = []

    for class_number, names in classrooms.items():
        for name in names:
            students.append({
                "class_number": class_number,
                "name": name
            })

    return students

def pick_random_students(count=DEFAULT_JUDGE_COUNT):

    students = get_all_students()
    sample_count = min(count, len(students))

    selected = random.sample(students, sample_count)

    return selected

def pick_evaluators_for_target(target, count=DEFAULT_JUDGE_COUNT):

    students = [
        student for student in get_all_students()
        if (
            student["class_number"] != target["class_number"]
            or student["name"] != target["name"]
        )
    ]
    sample_count = min(count, len(students))

    return random.sample(students, sample_count)
