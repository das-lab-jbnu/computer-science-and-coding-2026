import json

SCORE_FILE = "data/scores.json"
CRITERIA_FILE = "data/criteria.json"

def load_criteria():

    with open(CRITERIA_FILE, "r", encoding="utf-8") as file:
        criteria = json.load(file)

    return criteria

def save_score(evaluator, target, criteria_scores):

    with open(SCORE_FILE, "r", encoding="utf-8") as file:
        scores = json.load(file)

    total_score = sum(criteria_scores.values())

    scores.append({
        "evaluator": evaluator,
        "target": target,
        "criteria_scores": criteria_scores,
        "total_score": total_score
    })

    with open(SCORE_FILE, "w", encoding="utf-8") as file:
        json.dump(scores, file, indent=4, ensure_ascii=False)

def load_scores():

    with open(SCORE_FILE, "r", encoding="utf-8") as file:
        scores = json.load(file)

    return scores

def has_already_submitted(evaluator, target):

    scores = load_scores()

    for item in scores:

        if (
            item["evaluator"] == evaluator
            and item["target"] == target
        ):
            return True

    return False
