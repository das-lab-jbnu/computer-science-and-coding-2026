import json
import os

SETTINGS_FILE = "data/settings.json"
DEFAULT_SETTINGS = {
    "evaluation_closed": False,
    "closed_targets": []
}

def load_settings():

    if not os.path.exists(SETTINGS_FILE):
        return DEFAULT_SETTINGS.copy()

    with open(SETTINGS_FILE, "r", encoding="utf-8") as file:
        settings = json.load(file)

    merged = DEFAULT_SETTINGS.copy()
    merged.update(settings)

    return merged

def save_settings(settings):

    with open(SETTINGS_FILE, "w", encoding="utf-8") as file:
        json.dump(settings, file, indent=4, ensure_ascii=False)

def is_evaluation_closed():

    return load_settings()["evaluation_closed"]

def _target_key(target):

    return f'{target["class_number"]}:{target["name"]}'

def is_target_closed(target):

    settings = load_settings()

    return (
        settings["evaluation_closed"]
        or _target_key(target) in settings["closed_targets"]
    )

def close_target(target):

    settings = load_settings()
    key = _target_key(target)

    if key not in settings["closed_targets"]:
        settings["closed_targets"].append(key)

    save_settings(settings)

def reopen_target(target):

    settings = load_settings()
    key = _target_key(target)
    settings["closed_targets"] = [
        item for item in settings["closed_targets"]
        if item != key
    ]

    save_settings(settings)

def close_evaluation():

    settings = load_settings()
    settings["evaluation_closed"] = True
    save_settings(settings)

def reopen_evaluation():

    settings = load_settings()
    settings["evaluation_closed"] = False
    save_settings(settings)
