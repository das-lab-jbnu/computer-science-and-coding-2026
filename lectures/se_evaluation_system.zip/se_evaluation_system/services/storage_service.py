import csv
import os

CSV_FILE = "data/final_scores.csv"
FIELDNAMES = [
    "target_class",
    "target_name",
    "submitted_count",
    "student_average",
    "professor_score",
    "final_score"
]

def save_final_score(
    target,
    student_average,
    professor_score,
    final_score,
    submitted_count=""
):

    rows = []

    if os.path.isfile(CSV_FILE):
        with open(CSV_FILE, mode="r", newline="", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)

            for row in reader:
                if (
                    row.get("target_class") == target["class_number"]
                    and row.get("target_name") == target["name"]
                ):
                    continue

                rows.append(row)

    rows.append({
        "target_class": target["class_number"],
        "target_name": target["name"],
        "submitted_count": submitted_count,
        "student_average": student_average,
        "professor_score": professor_score,
        "final_score": final_score
    })

    save_all_final_scores(rows)

def save_all_final_scores(rows):

    with open(CSV_FILE, mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows([
            {field: row.get(field, "") for field in FIELDNAMES}
            for row in rows
        ])
