import pygame
import random

class Enemy:
    def __init__(self):
        self.x = random.randint(0, 1280)
        self.y = random.randint(0, 720)

    def update(self):
        self.x += 0.1

    def draw(self, screen):
        pygame.draw.circle(screen, "blue", (self.x, self.y), 20)

    def get_rect(self):
        return pygame.Rect(self.x-20, self.y-20, 40, 40)