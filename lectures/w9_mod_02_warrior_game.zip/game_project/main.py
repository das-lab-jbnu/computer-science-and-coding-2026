import pygame
from player import Player
from enemy import Enemy

pygame.init()


screen = pygame.display.set_mode((1280, 720))

player = Player()
enemies = [Enemy(), Enemy(), Enemy(), Enemy(), Enemy()]

running = True

#######
while running:


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for enemy in enemies:
        if player.get_rect().colliderect(enemy.get_rect()):
            running = False
    
    keys = pygame.key.get_pressed()

    player.update(keys)
    for enemy in enemies:
        enemy.update()

    screen.fill("black")


    player.draw(screen)
    for enemy in enemies:
        enemy.draw(screen)

    pygame.display.flip()

pygame.quit()