import pygame

class Player:
    def __init__(self):
        self.x = 640
        self.y = 360
    
    def update(self, keys):
        if keys[pygame.K_w]:
            self.y -= 1

        if keys[pygame.K_s]:
            self.y += 1

        if keys[pygame.K_a]:
            self.x -= 1

        if keys[pygame.K_d]:
            self.x += 1
    
    def draw(self, screen):
        pygame.draw.circle(screen, "red", (self.x, self.y), 40)

    def get_rect(self):
        return pygame.Rect(self.x-40, self.y-40, 80, 80)